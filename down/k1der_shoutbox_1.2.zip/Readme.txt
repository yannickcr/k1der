----------------------------------------
           K1der Shoutbox 1.2
        (Version distribuable)
              Par Country
             www.k1der.net
----------------------------------------

Apr�s maintes et maintes demandes (environ 2) voici la Shoutbox de K1der.net dans toute sa splendeur :)

Aller, je me lance :

Index
-----

1. Pr�sentation
2. Logiciels requis
3. Contenu du fichier zip
4. Installation
5. Configuration
6. Administration
7. Changelog
8. Remerciements

Vous avez pr�par� la bi�re et les chips ? Oui ? Alors on y va.

1. Pr�sentation
---------------

Alors ce que vous avez t�l�charg� est une Shoutbox, c'est � dire un petit endroit o� les visiteurs de votre site pourront laisser un court message (r�actions � un article, avis sur le site, insultes, menaces de mort, etc.).

Le succ�s de ce type de script est sans aucun doute la facilit�/rapidit� d'utilisation pour le visiteur.
Il tape son pseudo, son message, il valide et c'est fini.

Maintenant que vous savez ce que vous avez t�l�charg� et si vous �tes toujours int�ress� alors on peut passer � la suite.

2. Logiciels requis
-------------------

Sur la machine qui h�bergera le script vous devrez avoir:
- Php 4.x ou sup�rieur
- MySql 3.x ou sup�rieur

La majorit� des h�bergeurs poss�dent ces services (dont les h�bergeurs gratuits comme Free ou Multimania).
Un minimum de connaissances en HTML et Php/MySql est conseill�.

Et si vous avez beaucoup de connaissances en HTML et Php/MySql je pense que c'est pas la peine que vous vous fassiez chier a lire ce qui suit (ou alors pour le fun :p )

Les autres vous suivez ?

3. Contenu du fichier zip
-------------------------

k1dershoutbox12.zip
 |
 |-smileys              // Les images des smileys par d�fauts
 |    |-biggrin.gif
 |    |-bigrazz.gif
 |    |-confused.gif
 |    |-cool.gif
 |    |-mad.gif
 |    |-sad.gif
 |    |-smile.gif
 |    |-wink.gif
 |
 |-simleys blancs       // Les m�mes smileys mais en blanc (pour mettre sur un fond fonc�)
 |    |-biggrin.gif
 |    |-bigrazz.gif
 |    |-confused.gif
 |    |-cool.gif
 |    |-mad.gif
 |    |-sad.gif
 |    |-smile.gif
 |    |-wink.gif
 |
 |-admin.php            // Fichier d'administration
 |-board.php            // Shoutbox
 |-config.php           // Fichier de configuration
 |-exemple.php          // Exemple d'utilisation
 |-k1der_shoutbox.sql   // Table SQL � importer
 |-Readme.txt           // Vous �tes ici ;)
 |-styles.css           // Styles CSS de la Shoutbox (couleur des liens, du texte, etc.)
 
Vous avez tout �a ?
Alors on continue...

4. Installation
---------------

D�compressez tous les fichiers quelque part sur votre disque dur (en gardant l'arborescence).

Allez dans PhpMyAdmin (la plupart du temps il est accessible par l'interface d'administration de votre compte chez votre h�bergeur).

Si vous avez PhpMyAdmin 2.2.x :
- Cliquez sur le nom de votre base � gauche
- Dans la partie de droite, descendez jusqu'a arriver � "Ex�cuter une ou des requ�tes sur la base nomdelabase"
- Cliquez sur le bouton Parcourir et allez chercher le fichier k1der_shoutbox.sql sur votre disque.
- Cliquez sur Ex�cuter.

Si vous avez PhpMyAdmin 2.5.x :
- Cliquez sur le nom de votre base � gauche
- Dans la partie de droite, cliquez sur le lien "SQL" en haut.
- Cliquez sur le bouton Parcourir et allez chercher le fichier k1der_shoutbox.sql sur votre disque.
- Cliquez sur Ex�cuter.

Si vous avez une autre version, d�merdez vous :D

Uploadez ensuite tous les autres fichiers du zip (sauf le config.php) sur le ftp dans le dossier de votre choix (toujours en gardant l'arborescence)
(si vous avez r�ussi � y mettre votre site vous devez savoir comment faire :D )

Voila, c'est install� !
Ca ne marche pas ? C normal

5. Configuration
----------------

Ouvrez le fichier config.php avec Notepad:

Le reste du fichier est comment�, vous n'avez plus qu'� configurer tout �a selon vos pr�f�rences.

ATTENTION !
N'oubliez pas de changer les informations de connexion � la base de donn�e sinon �a ne marchera pas !

RE-ATTENTION !
N'oubliez pas de changer le login/mot de passe de l'administration, sinon c'est pas dr�le ;)

Pour changer les couleurs des liens, du texte, etc. Ouvrez le fichier styles.css avec Notepad (des connaissances en CSS sont requises).

Une fois que vous avez tout configur� vous pouvez uploader le fichier config.php (et styles.css si vous l'avez modifi�) dans le m�me dossier que les autres fichiers sur ftp.

Si tout est bien configur� alors �a devrai maintenant marcher.

Pour acc�der directement � la Shoutbox aller sur la page board.php : http://www.votresite.com/dossier/board.php

Vous trouverez aussi un exemple d'int�gration dans un site dans le fichier exemple.html : http://www.votresite.com/dossier/exemple.html
En gros �a se r�sume en 1 ligne:

<iframe src="dossier/board.php" frameborder="0" height="400" width="126"></iframe>
                    ^                                ^            ^
         Chemin vers le fichier                   Hauteur      Largeur

6. Administration
-----------------

Pour administrer la Shoutbox allez sur la page admin.php : http://www.votresite.com/dossier/admin.php
Identifiez vous avec le login et mot de passe rentr� dans le config.php (par d�faut les login et mot de passe sont tous les deux : admin)

Vous pouvez alors supprimer les messages de votre choix.

Pour vous d�connecter cliquez sur le bouton D�connecter (oui je sais j'ai beaucoup d'imagination) en haut � gauche de la fen�tre.

7. Changelog
------------

1.2
---
New:    Redistribuable
New:    Interface d'administration
New:    Options de configuration
Fix:    Bug quand une adresse mail et un lien se trouvaient dans 1 seul message
Change: Nettoyage du code

1.0
---
Premi�re version

8. Remerciement
---------------

Merci a Surprise pour ces id�es � la con :)
Merci � vous d'avoir t�l�charg� ce script
Et merci aux gens qui l'utilisent ;)

Infos et mises � jours : www.k1der.net