<?
/*----------------------------------------
            K1der Shoutbox 1.2
         (version redistribuable)
               par Country
              www.k1der.net
----------------------------------------*/

// Description : Interface d'administration de la shoutbox

// Configuration : voir le fichier config.php
include "config.php";

/*------Fonctions------*/

function sql($req) {
	global $sql;
	$db = mysql_connect($sql["server"],$sql["login"],$sql["pass"]) or die("Server SQL indisponible ou donn�es de connection erron�es");
	mysql_select_db($sql["base"],$db) or die("La base ".$sql_base." n'existe pas");
	$req=mysql_query($req) or die("Erreur SQL:<br>".mysql_error());
	mysql_close();
	return $req;
}

/*------Fin Fonctions------*/

if ($_POST) {

	if($_POST["login"]==$admin["login"] && $_POST["pass"]==$admin["pass"]) {
		setcookie("ident",md5($admin["pass"]));
		header("Location:".$_SERVER["SCRIPT_NAME"]);
	} else {
		header("Location:".$_SERVER["SCRIPT_NAME"]."?perdu=1");
	}
} else if ($_GET["deco"]==1) {
	setcookie("ident","");
	header("Location:".$_SERVER["SCRIPT_NAME"]);
} else if ($_GET["suppr"] && $_COOKIE["ident"]==md5($admin["pass"])) {
	sql("DELETE FROM ".$sql["table"]." WHERE id=\"".$_GET["suppr"]."\"");
	header("Location:".$_SERVER["SCRIPT_NAME"]."?action=ok");
}
?>
<html>
<head>
<title>K1der Shoutbox 1.2 : Administration</title>
<link href="styles.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript">
/*
Script pour afficher les bulles contenant la date et heure du message
*/
bname=navigator.appName;var Xpos=0;var Ypos=0;bversion=parseInt(navigator.appVersion);
var ebulle=0;

if (bname=="Netscape"){brows=true}
else{brows=false}

if(brows){
 document.captureEvents(Event.MOUSEMOVE);
 function MouveA(evnt) {
  Xpos = evnt.pageX+window.pageXOffset;
  Ypos = evnt.pageY+window.pageYOffset;
 }
 document.onMouseMove = MouveA;}
else {
 function MouveB() {
  Xpos = event.clientX+document.body.scrollLeft;
  Ypos = event.clientY+document.body.scrollTop;
 }
 document.onmousemove = MouveB;
}

function bubulle() {
 var cx;var cy;
 cx=Xpos+5;cy=Ypos-37;
 if (brows) {document.text.left=cx;document.text.top=cy;}
 else {document.all.text.style.left=cx;document.all.text.style.top=cy;}
 setTimeout("bubulle()",10)
}

function bulle(texte){
 if (ebulle==0) {
  if (brows){
   document.layers['text'].document.writeln('<?=$labulle;?>');
   document.layers['text'].document.close();
  }
  else{
   text.innerHTML='<?=$labulle;?>';
  }
  ebulle=1;
 }
}

function cbulle(){
 if (brows){document.layers['text'].document.writeln('');document.layers['text'].document.close();}
 else{text.innerHTML='';}
 ebulle=0;
}
</script>
</head>
<body onload="bubulle();">
<div id="text" style="position:absolute;left:4px;top:80px;width:1px;height:1px;"></div>
<Layer name="text" left="4" top="80" width="100" height="16"></Layer>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td class="titre">Administration</td>
		<td class="titre2">
		<?
		if ($_COOKIE["ident"]==md5($admin["pass"])) { 
		?>
		<a href="<?=$_SERVER["SCRIPT_NAME"];?>?deco=1">D�connection</a>
		<?
		}
		?>
		</td>
	</tr>
	<? if ($_COOKIE["ident"]!=md5($admin["pass"])) { ?>
	<tr>
		<td align="center" colspan="2">
		<br/><br/><br/><b>Identification</b><br/><br/>
		<form name="form" action="<?=$_SERVER["SCRIPT_NAME"];?>?act=add" method="post">
		<? if ($_GET["perdu"]==1) echo "<span class=\"erreur\">Login ou mot de passe incorrect</span><br/><br/>"; ?>
		<input type="text" name="login" onfocus="this.value=''" value="login" size="17"><br/>
    <input type="password" name="pass" onfocus="this.value=''" value="pass" size="17"><br/>
    <input type="submit" value="Valider" name="Submit"><br/><br/>
    </form>
		</td>
	</tr>
	<? } else { ?>
	<tr>
		<td colspan="2">
		<div style="margin:20px;">
		<? if ($_GET["action"]=="ok") echo "<div class=\"info\">Suppression effectu�e avec succ�s</div><br/>"; ?>
		<table width="50%" class="liste" align="center" cellspacing="1" cellpadding="2">
			<?
		$style="td1";
		$req = sql("SELECT * FROM ".$sql["table"]." ORDER BY id DESC");
		while($disp = mysql_fetch_array($req))
		{
		$date = date("d/m/Y",$disp[timestamp]);
		$heure = date("H:i",$disp[timestamp]);
		$mess = stripslashes($disp[mess]);
		$pseudo = stripslashes($disp[pseudo]) ;
		?>
			<tr> 
				<td width="90%" class="<?=$style;?>">
				<a class="pseudo" onmouseover="bulle('le <?=$date;?><br>� <?=$heure;?>')" onmouseout="cbulle()"><?=$pseudo;?></a> : <?=$mess;?>
				</td>
				<td width="10%" align="center" class="<?=$style;?>">
				<a href="<?=$_SERVER["SCRIPT_NAME"]."?suppr=".$disp["id"];?>">Supprimer</a>
				</td>
			</tr>
		<?
		if ($style=="td1") $style="td2";
		else $style="td1";
		}
		?>
		</table></div>
		</td>
	</tr>
<? } ?>
</table>
</body>
</html>