<?
/*----------------------------------------
            K1der Shoutbox 1.2
         (version redistribuable)
               par Country
              www.k1der.net
----------------------------------------*/

// Description : Fichier principal contenant la shoutbox, la page d'aide et l'historique

// Configuration : voir le fichier config.php
include "config.php";

/*------Fonctions------*/

//Requete SQL
function sql($req) {
	global $sql;
	$db = mysql_connect($sql["server"],$sql["login"],$sql["pass"]) or die("Server SQL indisponible ou donn�es de connection erron�es");
	mysql_select_db($sql["base"],$db) or die("La base ".$sql_base." n'existe pas");
	$req=mysql_query($req) or die("Erreur SQL:<br>".mysql_error());
	mysql_close();
	return $req;
}

//Formatage du message
function replace($text) {
	global $replace,$smileys,$smi_rep,$long_max,$nb_carac;
	// Remplacement des Liens (on vire les tags html en m�me temps)
	$tab1=array("http://www.","www.");
	$tab2=array("www.","http://www.");
	$text = str_replace($tab1,$tab2,strip_tags($text));
	$text = eregi_replace(
		"([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])",
		"<a href=\"\\1://\\2\\3\" target=\"_blank\">".$replace["liens"]."</a>"
	,$text);
	// Remplacement des Mails
	$text = eregi_replace(
		"([_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)+)",
    "<a href=\"mailto:\\1\">".$replace["mails"]."</a>"
	,$text);
	// On coupe les mots trop longs
	$text=wordwrap($text,$long_max," ",1);
	// Et merde ! Sa a couper les liens et mails aussi :(
	// Alors on extrait les liens et mails et on supprime les espaces dedant
	$masque = '`((\<))(.*?)((?<!\\\)(?(2)>))`s';
	$tab1=array(" ","ahref","\"target");
	$tab2=array("","a href","\" target");
	preg_match_all($masque,$text,$array);
	foreach($array[3] as $resultat) $text=str_replace($resultat,str_replace($tab1,$tab2,$resultat),$text);
	// On passe aux smileys
	foreach($smileys as $code => $image) $text=str_replace($code,"<img align=\"top\" alt=\"".$code."\" src=\"".$smi_rep."/".$image."\">",$text);
	$text = substr($text, 0, $nb_carac);
	// On retourne le texte avec des slashes pour �viter les erreurs
	return addslashes($text);
}

/*------Fin Fonctions------*/

// Ajout d'un message
if ($_GET["act"] == "add")
{
	$info = mysql_fetch_array(sql("SELECT mess FROM ".$sql["table"]." ORDER BY id DESC LIMIT 0,1"));
	$mess_prec = $info["mess"];	
	
	$text = replace($_POST["message"]);
	$pseudo = addslashes($pseudo) ;
	$times = date('U');
	if($mess_prec!=$text && !empty($text) && $text!="message") sql("INSERT INTO ".$sql["table"]." (timestamp,pseudo,mess) VALUES (\"".$times."\",\"".$pseudo."\",\"".$text."\")");
	header("Location:".$_SERVER["SCRIPT_NAME"]."?pseudo=".$_POST["pseudo"]);
}
?>
<html>
<head>
<title>K1der Shoutbox 1.2</title>
<link href="styles.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript">
/*
Script pour afficher les bulles contenant la date et heure du message
*/
bname=navigator.appName;var Xpos=0;var Ypos=0;bversion=parseInt(navigator.appVersion);
var ebulle=0;

if (bname=="Netscape"){brows=true}
else{brows=false}

if(brows){
 document.captureEvents(Event.MOUSEMOVE);
 function MouveA(evnt) {
  Xpos = evnt.pageX+window.pageXOffset;
  Ypos = evnt.pageY+window.pageYOffset;
 }
 document.onMouseMove = MouveA;}
else {
 function MouveB() {
  Xpos = event.clientX+document.body.scrollLeft;
  Ypos = event.clientY+document.body.scrollTop;
 }
 document.onmousemove = MouveB;
}

function bubulle() {
 var cx;var cy;
 cx=Xpos+5;cy=Ypos-37;
 if (brows) {document.text.left=cx;document.text.top=cy;}
 else {document.all.text.style.left=cx;document.all.text.style.top=cy;}
 setTimeout("bubulle()",10)
}

function bulle(texte){
 if (ebulle==0) {
  if (brows){
   document.layers['text'].document.writeln('<?=$labulle;?>');
   document.layers['text'].document.close();
  }
  else{
   text.innerHTML='<?=$labulle;?>';
  }
  ebulle=1;
 }
}

function cbulle(){
 if (brows){document.layers['text'].document.writeln('');document.layers['text'].document.close();}
 else{text.innerHTML='';}
 ebulle=0;
}
/*
Script ouvrant une pop-up pour l'aide ou l'historique
*/
function openScript(url, width, height) {
        var Win = window.open(url,'','width=' + width + ',height=' + height + ',resizable=no,scrollbars=yes,menubar=no,status=no' );
}
</script>
</head>
<?
if ($_GET["act"] != 'all') $scroll="no";
else $scroll="yes";
?>
<body scroll="<?=$scroll;?>" onload="bubulle();">
<div id="text" style="position:absolute;left:4px;top:80px;width:1px;height:1px;"></div>
<Layer name="text" left="4" top="80" width="100" height="16"></Layer>
<div align="center">
<?
// Affichage de l'aide
if ($_GET["act"] == 'help')
{
?>
<table width="100" border="0" cellspacing="3" cellpadding="0">
	<tr> 
		<td width="50%" align="center"><b>Code</b></td>
		<td width="50%" align="center"><b>Smiley</b></td>
	</tr>
	<?
	foreach($smileys as $code => $image) {
	?>
	<tr> 
		<td width="50%" align="center"><?=$code;?></td>
		<td width="50%" align="center"><img alt="<?=$code;?>" src="<?=$smi_rep."/".$image;?>"></td>
	</tr>
	<? } ?>
</table>
</div>
<br/>
<div align="center">
	[ <a href="javascript:self.close()">Fermer</a> ]<br/><br/>
	<b>Script : </b><a href="http://www.k1der.net" target="_blank"><font color="#666666">K1der Shoutbox 1.2</font></a>
</div>
</body>
</html>
<?
exit;
}
?>
<?
// Si on veut afficher tous les messages
if ($_GET["act"] == 'all') $req = sql("SELECT * FROM ".$sql["table"]." ORDER BY id DESC");
// Sinon affichage normal
else $req = sql("SELECT * FROM ".$sql["table"]." ORDER BY id DESC LIMIT 0,".$nb_mess);

$nbre=mysql_fetch_row(sql("SELECT COUNT(*) FROM ".$sql["table"])); //Comptage du nombre de messages
?>
<table width="<?=$width;?>" border="0" cellspacing="0" cellpadding="0">
	<?
  if ($_GET["act"] != 'all')
	{
		if ($_GET["pseudo"]) {
			$contenu=$_GET["pseudo"];	
			$lien="?pseudo=".$_GET["pseudo"];
		}	else {
			$contenu="pseudo";
			unset($lien);
		}
		$hauteur=count($smileys)*22+45;
		if($nbre[0]>1) $esse="s";
		else unset($esse);
		?>
 <tr>
	<td align="center">[ <A href="javascript:openScript('<?=$_SERVER["SCRIPT_NAME"];?>?act=all','<?=($width+80);?>','600')">Historique</a> : <A href="javascript:openScript('<?=$_SERVER["SCRIPT_NAME"];?>?act=help','150','<?=$hauteur;?>')">Aide</a> ]<br/><br/></td>
 </tr>
 <tr> 
  <td align="center">
   <form name="form" action="<?=$_SERVER["SCRIPT_NAME"];?>?act=add" method="post">
   <? echo "<b>".$nbre[0]."</b><br>message".$esse." post�".$esse."<br>"; ?><br/>
   <input name="pseudo" onfocus="this.value=''" value="<?=$contenu?>" size="17"><br/>
   <input name="message" onfocus="this.value=''" value="message" size="17" maxlength="<?=$nb_carac;?>"><br/>
   <input type="submit" value="Poster" name="Submit"><br/><br/>
   [ <A href="<?=$_SERVER["SCRIPT_NAME"].$lien;?>">Actualiser</A> ] 
   </form><br/>
  </td>
 </tr>
 <?
 }
 ?>
 <tr>
  <td>
   <table width="<?=$width;?>" class="liste" cellspacing="1" cellpadding="2">
   <?
   $style="td1";
   while($disp = mysql_fetch_array($req)) {
    $date = date("d/m/Y",$disp[timestamp]);
    $heure = date("H:i",$disp[timestamp]);
    $mess = substr(stripslashes($disp[mess]),0,$nb_carac);
    $pseudo = stripslashes($disp[pseudo]) ;
   ?>
 <tr>
     <td width="<?=$width;?>" class="<?=$style;?>">
      <a class="pseudo" onmouseover="bulle('le <?=$date;?><br>� <?=$heure;?>')" onmouseout="cbulle()"><?=$pseudo;?></a> : <?=$mess."\n";?>
     </td>
    </tr>
    <?
    if ($style=="td1") $style="td2";
    else $style="td1";
    }
    ?>
</table>
  </td>
 </tr>
</table>
</body>
</html>