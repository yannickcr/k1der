<?
/*----------------------------------------
            K1der Shoutbox 1.2
         (version redistribuable)
               par Country
              www.k1der.net
----------------------------------------*/

// Description : Fichier de configuration de la shoutbox

// Style du texte, des liens, etc... : voir fichier styles.css

// Acc�s � la base de donn�e (importez k1der_shoutbox.sql avant)
$sql["server"]="localhost";
$sql["login"]="root";
$sql["pass"]="";
$sql["base"]="k1der1";
$sql["table"]="k1der_shoutbox"; // Ne modifier seulement si vous avez chang� le nom de la table dans le fichier k1der_shoutbox.sql

// Acc�s � l'administration
$admin["login"]="admin";
$admin["pass"]="admin";

// R�pertoire des smileys
$smi_rep="smileys";

// Smileys � remplacer
$smileys=array(
":)"=>"smile.gif",
":("=>"sad.gif",
";)"=>"wink.gif",
":p"=>"bigrazz.gif",
":D"=>"biggrin.gif",
":@"=>"mad.gif",
"8)"=>"cool.gif",
"???"=>"confused.gif"
);

// Texte de remplacement pour les liens et les mails
$replace["liens"]="[lien]";
$replace["mails"]="[mail]";

// Nombre de messages � afficher
$nb_mess=15;

// Nombre max de carat�re du message
$nb_carac=90;

// Longueur max des mots
$long_max=15;

// Largeur de la shoutbox (en pixels)
$width=126;

// Bulle avec la date et l'heure du post ('+texte+' pour le texte le texte � afficher)
$labulle ="<table class=\"bulle\" cellpading=\"1\" cellspacing=\"1\">";
$labulle.=" <tr>";
$labulle.="  <td>";
$labulle.="   <nobr>'+texte+'</nobr>";
$labulle.="  </td>";
$labulle.=" </tr>";
$labulle.="</table>";

?>