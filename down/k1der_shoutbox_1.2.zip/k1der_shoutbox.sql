# ----------------------------------------
#            K1der Shoutbox 1.2
#         (version redistribuable)
#               par Country
#              www.k1der.net
# ----------------------------------------
#
# Description : Fichier d'importation MySql
#

CREATE TABLE k1der_shoutbox (
  id int(6) NOT NULL auto_increment,
  timestamp int(10) NOT NULL,
  pseudo varchar(200) NOT NULL default '',
  mess text NOT NULL,
  UNIQUE KEY id (id)
) TYPE=MyISAM;