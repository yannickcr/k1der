<?
/*----------------------------------------
            K1der Shoutbox 1.7 Beta2
               par Country
              www.k1der.net
----------------------------------------*/

// Description : index du shoutbox (ne contenant que l'iframe correctement dimentionn�e)

$dir=dirname($PATH_TRANSLATED);
if(!file_exists($dir."/config.php")) header("location:".str_replace($_SERVER["DOCUMENT_ROOT"],"",$dir)."/install.php");
else include $dir."/config.php";
include $dir."/include/fonctions.php";
$req=sql("SELECT nom,valeur FROM ".$sql["table2"]." WHERE nom=\"hauteur\" or nom=\"largeur\"");
while($info=mysql_fetch_array($req)) $$info["nom"]=$info["valeur"];
?>
<!-- D�but K1der Shoutbox 1.7 Beta2 | www.k1der.net -->
<iframe src="<?=str_replace($_SERVER["DOCUMENT_ROOT"],"",$dir);?>/board.php" frameborder="0" scrolling="no" width="<?=$largeur;?>" height="<?=$hauteur;?>"></iframe>
<!-- Fin K1der Shoutbox 1.7 Beta2 | www.k1der.net -->
