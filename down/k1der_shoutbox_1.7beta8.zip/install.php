<?
/*----------------------------------------
            K1der Shoutbox 1.7 Beta8
               par Country
              www.k1der.net
----------------------------------------*/

// Description : fichier d'installation du shoutbox

if(file_exists("install.lock")) {
	head();
?>
<table class="admtab" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" class="titre">Installation V�rouill�e</td>
	</tr>
	<tr>
	  <td colspan="2" style="height:20px;">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Acc�s refus�</td>
  </tr>
	<tr>
    <td colspan="2"><br />L'installation de ce shoutbox est v�rouill�e.<br />Si vous voulez effectuer une nouvelle installation supprimez le fichier &quot;install.lock&quot; qui se trouve dans le r�pertoire du shoutbox.</td>
  </tr>
</table>
<?
	foot();
	exit();
}

$ver="1.7";
switch($_GET["etape"])
{
	case '1':
		etape1();
		break;
		
	case '2':
		etape2();
		break;
		
	case '3':
		etape3();
		break;
		
	default:
		intro();
		break;
}

function head() {
	global $ver;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>K1der Shoutbox <?=$ver;?> : Installation</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="include/styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<?
}
function foot() {
?>
</body>
</html>
<?
}

function intro() {
	global $ver;
	head();
	?>
<form action="?etape=1" method="post">
<table class="admtab" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" class="titre">Installation du K1der Shoutbox <?=$ver;?></td>
	</tr>
	<tr>
	  <td colspan="2" style="height:20px;">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Installation</td>
  </tr>
	<tr>
    <td colspan="2"><br />Bienvenue dans le module d'installation du K1der Shoutbox <?=$ver;?>.<br />Ce module vous guidera tous du long de l'installation afin que celle-ci ne se d�roule sans probl�mes.</td>
  </tr>
	<tr>
    <td colspan="2"><br />Veuillez s�lectionner le type d'installation que vous souhaitez effectuer:</td>
  </tr>
	<tr>
    <td colspan="2"><br /><input type="radio" name="type" value="new" checked="checked" />&nbsp;Installation compl�te</td>
  </tr>
	<tr>
    <td colspan="2"><input type="radio" name="type" value="maj" />&nbsp;Mise � jour � partir de la version 1.2</td>
  </tr>
	<tr>
    <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2">PS : Si vous effectuez une mise � jour � partir d'une version sup�rieure � la 1.2 alors l'installation n'est pas n�cessaire. Remplacez simplement les fichiers de l'ancienne version par les nouveaux (hormis le fichier styles.css si 
		vous voulez garder vos styles personnalis�s).</td>
  </tr>
	<tr>
    <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" align="center"><input type="submit" name="submit" value="Continuer..." /></td>
  </tr>
</table>
</form>
	<?
	foot();
}

function etape1() {
	global $ver;
	head();

$url = str_replace( "/install.php", "", $_SERVER['HTTP_REFERER']);
if (!$url) {
	$url = $url = str_replace( "/install.php", "", $_SERVER['SCRIPT_NAME']);
	if ($url == '') {
		$url == '/';
	}
	$url = 'http://'.$_SERVER['SERVER_NAME'].$url; 
} 

if($_POST["type"]=="maj") {
	if(file_exists("config.php")) include "config.php";
	$sql_server=$sql["server"];
	$sql_base=$sql["base"];
	$sql_login=$sql["login"];
	$sql_pass=$sql["pass"];
	$sql_table=$sql["table"];
	
	$adm_login=$admin["login"];
	$adm_pass=$admin["pass"];
} else {
unset($sql_base,$sql_login,$sql_pass,$adm_login,$adm_pass,$adm_pass2);
	$sql_server="localhost";
	$sql_table="k1der_shoutbox";
}
?>
<form action="?etape=2" method="post">
<table class="admtab" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" class="titre">Installation du K1der Shoutbox <?=$ver;?></td>
	</tr>
	<tr>
	  <td colspan="2" style="height:20px;"><input type="hidden" name="type" value="<?=$_POST["type"];?>" /></td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Dossier du script</td>
  </tr>
	<tr>
    <td colspan="2">Vous devez rentrer le dossier dans lequel est install&eacute; le script sur votre serveur.</td>
  </tr>
	<tr>
    <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td nowrap="nowrap">Dossier d'intallation<br/>
      <span>(doit commencer par http://)</span></td>
    <td><input name="script_url" type="text" id="script_url" value="<?=$url;?>"></td>
  </tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td colspan="2" class="titre3">&loz;&nbsp;Configuration de la base de donn�e</td>
	</tr>
	<tr>
	  <td colspan="2">Vous devez rentrer les informations de votre base SQL. Si vous avez un doute sur l'une d'entre elles renseignez-vous aupr&egrave;s de  votre h&eacute;bergeur.</td>
  </tr>
	<tr>
		<td colspan="2">&nbsp;</td>
	</tr>
	<tr>
		<td nowrap="nowrap">Serveur SQL</td><td width="70%"><input name="sql_server" type="text" id="sql_server" value="<?=$sql_server;?>"></td>
	</tr>
	<tr>
		<td nowrap="nowrap">Nom de la base SQL</td><td width="70%"><input name="sql_base" type="text" id="sql_base" value="<?=$sql_base;?>"></td>
	</tr>
	<tr>
		<td nowrap="nowrap">Login de la base SQL</td><td width="70%"><input name="sql_login" type="text" id="sql_login" value="<?=$sql_login;?>"></td>
	</tr>
	<tr>
		<td nowrap="nowrap">Mot de passe de la base SQL</td><td width="70%"><input name="sql_pass" type="password" id="sql_pass" value="<?=$sql_pass;?>"></td>
	</tr>
	<tr>
		<td nowrap="nowrap">Nom de la table du shoutbox</td><td width="70%"><input name="sql_table" type="text" id="sql_table" value="k1der_shoutbox" value="<?=$sql_table;?>"></td>
	</tr>
	<tr>
		<td nowrap="nowrap">Nom de la table de configuration du shoutbox</td><td width="70%"><input name="sql_table2" type="text" id="sql_table" value="k1der_shoutbox_config" value="<?=$sql_table2;?>"></td>
	</tr>
	<tr>
	  <td nowrap="nowrap">&nbsp;</td>
	  <td>&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Compte administrateur </td>
  </tr>
	<tr>
    <td colspan="2">Vous devez rentrer les informations concernant le compte administrateur.</td>
  </tr>
	<tr>
    <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td nowrap="nowrap">Login</td>
    <td><input name="adm_login" type="text" id="adm_login" value="<?=$adm_login;?>"></td>
  </tr>
	<tr>
    <td nowrap="nowrap">Mot de passe </td>
    <td><input name="adm_pass" type="password" id="adm_pass" value="<?=$adm_pass;?>"></td>
	  </tr>
	<tr>
    <td nowrap="nowrap">Confirmation du mot de passe </td>
    <td><input name="adm_pass2" type="password" id="adm_pass2" value="<?=$adm_pass;?>"></td>
  </tr>
	<tr>
	  <td colspan="2" nowrap="nowrap">&nbsp;</td>
  </tr>
	<tr>
	  <td colspan="2" nowrap="nowrap" align="center"><input class="submit" type="submit" value="Lancer l'installation..."></td>
  </tr>
	<tr>
	  <td colspan="2" nowrap="nowrap">&nbsp;</td>
  </tr>
</table>
</form>
<?
foot();
}

function etape2() {
unset($error);
	// Partie 1 : url du script
	if(empty($_POST["script_url"])) $error.="- Vous devez rentrer l'url du dossier du script.<br/>";
	else if(!ereg("http://",$_POST["script_url"])) $error.="- L'url du dossier du script doit commencer par http://<br/>";
	
	// Partie 2 : serveur SQL (c'est d�j� plus s�rieux ;)
	
	if(empty($_POST["sql_server"])) $error.="- Vous devez rentrer l'adresse du serveur SQL.<br/>";
	else if (!$sql = @mysql_connect($_POST["sql_server"],$_POST["sql_login"],$_POST["sql_pass"])) {
		$error.="- Impossible de se connecter au serveur SQL, cela peut �tre d� � une mauvaise adresse de serveur, un mauvais login ou un mauvais mot de passe.<br/>";
	} else if(empty($_POST["sql_base"])) $error.="- Vous devez rentrer le nom de la base SQL.<br/>";
	else if (!@mysql_select_db($_POST["sql_base"],$sql) ) {
		$error.="- Base '".$_POST["sql_base"]."' introuvable<br/>";
	}
	if(empty($_POST["sql_table"])) $error.="- Vous devez rentrer le nom de la table du shoutbox.<br/>";
	if(empty($_POST["sql_table2"])) $error.="- Vous devez rentrer le nom de la table de configuration du shoutbox.<br/>";
	if($_POST["sql_table"]==$_POST["sql_table2"]) $error.="- Vous devez rentrer une table diff�rente pour le shoutbox et la configuration.<br/>";
	if (!$fp=@fopen("config.php",'w')) $error.="- Erreur d'�criture du config.php (les droits d'acc�s du dossier/fichier sont probablements incorrects).<br/>";
	else @fclose($fp);

	// Partie 3 : compte administrateur
	if(empty($_POST["adm_login"])) $error.="- Vous devez rentrer un login pour le compte d'administrateur.<br/>";
	if(empty($_POST["adm_pass"])) $error.="- Vous devez rentrer un mot de passe pour le compte d'administrateur.<br/>";
	else if($_POST["adm_pass"]!=$_POST["adm_pass2"]) $error.="- La confirmation du mot de passe � �chou�e.<br/>";
	
	if(!$error) {
		setcookie("login",$_POST["adm_login"]);
		setcookie("pass",md5($_POST["adm_pass"]));
	}
	
	head();
	
	if(!$error) {
		install();
	?>	
<table class="admtab" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" class="titre">Installation du K1der Shoutbox <?=$ver;?></td>
	</tr>
	<tr>
	  <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Installation termin�e</td>
  </tr>
	<tr>
	  <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
		<td colspan="2">Votre shoutbox a �t� install� avec succ�s.<br/>Pour l'int�grer � votre site ins�rez ce code � l'endroit o� vous voulez la voir apparaitre :</td>
	</tr>
	<tr>
	  <td colspan="2" style="padding-top:20px; padding-bottom:20px;"><code>&lt;? include &quot;<?=$_POST["script_url"];?>/index.php&quot;; ?&gt;</code></td>
  </tr>
	<tr>
	  <td colspan="2">L'installation � �t� v�rouill�e, pour la d�v�rouiller supprimez le fichier install.lock</td>
  </tr>
	<tr>
	  <td colspan="2" style="padding-bottom:20px;">Pour plus de s�curit� vous pouvez aussi supprimer le fichier install.php</td>
  </tr>
	<tr>
	  <td colspan="2" align="center"><input class="submit" type="button" onclick="javascript:window.location='<?=$_POST["script_url"];?>/admin.php?action=conf';" value="Configurer le shoutbox" /></td>
  </tr>
	<tr>
	  <td colspan="2" nowrap="nowrap">&nbsp;</td>
  </tr>
</table>
<?		
	} else {
?>
<table class="admtab" width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td colspan="2" class="titre">Installation du K1der Shoutbox <?=$ver;?></td>
	</tr>
	<tr>
	  <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
    <td colspan="2" class="titre3">&loz;&nbsp;Erreur !</td>
  </tr>
	<tr>
    <td colspan="2">Les erreurs suivantes ont �t�s d�tect�es dans vos informations.</td>
  </tr>
	<tr>
	  <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
		<td colspan="2"><?=$error;?></td>
	</tr>
	<tr>
	  <td colspan="2">&nbsp;</td>
  </tr>
	<tr>
	  <td colspan="2" align="center"><input class="submit" type="button" onclick="javascript:history.back();" value="Modifier les informations" /></td>
  </tr>
	<tr>
	  <td colspan="2" nowrap="nowrap">&nbsp;</td>
  </tr>
</table>
<?
	}
	
	foot();
	
}

function install() {

// Si il s'agit d'une mise � jour : r�cup�ration des infos dans le config.php
if($_POST["type"]=="maj" && file_exists("config.php")) {
	include "config.php";
	$insert_smi_rep=$smi_rep;
	if(is_array($smileys)) {
		foreach($smileys as $i => $var) {
			$insert_smileys.=$i."=>".$var."=>";
		}
		$insert_smileys=substr($insert_smileys, 0,(strlen($insert_smileys)-2)); 
	}
	$insert_liens=$replace["liens"];
	$insert_mails=$replace["mails"];
	$insert_nb_mess=$nb_mess;
	$insert_nb_carac=$nb_carac;
	$insert_long_max=$long_max;
	$insert_largeur=$width;
// Sinon on met les valeurs par d�faut
}
	if (empty($insert_smi_rep))   $insert_smi_rep="smileys";
	if (empty($insert_smileys)) 	$insert_smileys=":)=>smile.gif=>:(=>sad.gif=>;)=>wink.gif=>:p=>tongue.gif=>:D=>biggrin.gif=>:@=>mad.gif=>8)=>cool.gif=>:o=>ohmy.gif=>^^=>happy.gif=><_<=>dry.gif=>:'(=>cry.gif=>-_-=>sleep.gif";
	if (empty($insert_liens)) 	  $insert_liens="[lien]";
	if (empty($insert_mails)) 	  $insert_mails="[mail]";
	if (empty($insert_nb_mess)) 	$insert_nb_mess=15;
	if (empty($insert_nb_carac)) 	$insert_nb_carac=90;
	if (empty($insert_long_ma)) 	$insert_long_max=15;
	if (empty($insert_largeur)) 	$insert_largeur=126;
			
$text="<?\n";
$text.="/*----------------------------------------\n";
$text.="            K1der Shoutbox 1.7 Beta8\n";
$text.="               par Country\n";
$text.="              www.k1der.net\n";
$text.="----------------------------------------*/\n\n";
$text.="// Description : Param�tres de la configuration SQL\n\n";
$text.="\$sql[\"server\"]=\"".$_POST["sql_server"]."\";\n";
$text.="\$sql[\"login\"]=\"".$_POST["sql_login"]."\";\n";
$text.="\$sql[\"pass\"]=\"".$_POST["sql_pass"]."\";\n";
$text.="\$sql[\"base\"]=\"".$_POST["sql_base"]."\";\n";
$text.="\$sql[\"table\"]=\"".$_POST["sql_table"]."\";\n";
$text.="\$sql[\"table2\"]=\"".$_POST["sql_table2"]."\";\n";
$text.="?>";

	// Ecriture du config.php
	 $fp=@fopen("config.php",'w');
	 @fputs($fp,$text,strlen($text));
	 @fclose($fp);
		// Cr�ation de la table
		
		$sql = mysql_connect($_POST["sql_server"],$_POST["sql_login"],$_POST["sql_pass"]);
		mysql_select_db($_POST["sql_base"],$sql);
		if(!mysql_table_exists($_POST["sql_table"],$_POST["sql_base"])) {
				mysql_query("CREATE TABLE `".$_POST["sql_table"]."` (
				`id` int(6) NOT NULL auto_increment,
				`ip` varchar(15) NOT NULL default '',
				`timestamp` int(10) NOT NULL default '0',
				`pseudo` varchar(200) NOT NULL default '',
				`mess` text NOT NULL,
				UNIQUE KEY `id` (`id`)
			) TYPE=MyISAM;");
		// Si elle existe on convertit les enregistrements de la 1.2 en enregistrements de la 1.7 ou +
		} else if($_POST["type"]=="maj") {
			@mysql_query("ALTER TABLE `".$_POST["sql_table"]."` ADD `ip` VARCHAR(15) NOT NULL AFTER `id`");
			$seq=@mysql_query("SELECT id,mess FROM ".$_POST["sql_table"]." WHERE mess like \"%a href%\" or mess like \"%img src%\"");
			while($info=@mysql_fetch_array($seq)) {
				@mysql_query("UPADTE ".$_POST["sql_table"]." SET mess=\"".convert($info["mess"])."\" WHERE id=\"".$info["id"]."\"");
			}
		}
		// Table de configuration, cr�ation et remplissage
		if(!mysql_table_exists($_POST["sql_table2"],$_POST["sql_base"])) {
				mysql_query("CREATE TABLE `".$_POST["sql_table2"]."` (
  `nom` varchar(100) NOT NULL default '',
  `valeur` varchar(250) NOT NULL default ''
) TYPE=MyISAM;");		
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"admin_login\",\"".$_POST["adm_login"]."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"admin_pass\",\"".md5($_POST["adm_pass"])."\")");

			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"smileys\",\"".$insert_smileys."\")");

			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"liens\",\"".$insert_liens."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"mails\",\"".$insert_mails."\")");
			
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"nb_mess\",\"".$insert_nb_mess."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"nb_carac\",\"".$insert_nb_carac."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"long_max\",\"".$insert_long_max."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"largeur\",\"".$insert_largeur."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"hauteur\",\"400\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"rep_shout\",\"".$_POST["script_url"]."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"rep_smileys\",\"".$insert_smi_rep."\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"nb_posts\",\"1\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"lien_adm\",\"0\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"pl_liens\",\"haut\")");
			mysql_query("INSERT INTO ".$_POST["sql_table2"]." (nom,valeur) VALUES (\"secu_pseudo\",\"0\")");
		}
	
	mysql_close();
	$fp=@fopen("install.lock","w");
	@fclose($fp);
}

function convert($text) {
	// Remplacement des Liens (on vire les tags html en m�me temps)
	$text = eregi_replace(
		"<a href=\"([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])\" target=\"_blank\">([^[:space:]]*)([[:alnum:][:punct:]#?/&=])</a>",
		"\\1://\\2\\3"
	,$text);
	// Remplacement des Mails
	$text = eregi_replace(
		"<a href=\"mailto:([_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)+)\">([^[:space:]]*)([[:alnum:][:punct:]#?/&=])</a>",
    "\\1"
	,$text);
	// Remplacement des smileys
	$text = eregi_replace(
"<img src=\"([^[:space:]]*[[:alnum:]#?/&=])\" alt=\"([^[:space:]]*[[:alnum:][:punct:]#?/&=])\"/>",
    "\\2"
	,$text);
	// On retourne le texte modifi�
	return $text;
}

function mysql_table_exists($table , $db){ 
	$tables=mysql_list_tables($db); 
	while (list($temp)=mysql_fetch_array($tables)) {
		if($temp==$table) return 1;
	} 
	return 0; 
}

?>