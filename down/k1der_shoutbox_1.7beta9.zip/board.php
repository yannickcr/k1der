<?php
/*----------------------------------------
            K1der Shoutbox 1.7 Beta9
               par Country
              www.k1der.net
----------------------------------------*/

// Description : Fichier principal contenant le shoutbox, la page d'aide et l'historique

// Configuration SQL : voir le fichier config.php
if(!file_exists("config.php")) header("location:install.php");
else include "config.php";
include "include/fonctions.php";

// Ajout d'un message
if ($_POST && $_GET["act"] == "add") add_mess($_POST);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>K1der Shoutbox 1.7</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="include/styles.css" rel="stylesheet" type="text/css" />
<script language="javascript" type="text/javascript" src="include/scripts.js"></script>
</head>
<?php
if (isset($_GET["act"]) && $_GET["act"]== 'histo' || $scroll=="oui") $scrolling="auto";
else $scrolling="hidden";
?>
<body style="overflow:<?php echo $scrolling;?>;">
<div id="bulle"></div>
<?php
// Affichage de l'aide
if (isset($_GET["act"]) && $_GET["act"] == 'help')
{
?>
<table width="<?php echo $largeur; ?>" border="0" cellspacing="3" cellpadding="0">
	<tr> 
		<td width="50%" align="center"><b>Code</b></td>
		<td width="50%" align="center"><b>Smiley</b></td>
	</tr>
	<?php
	foreach($smileys as $code => $image) {
	?>
	<tr> 
		<td width="50%" align="center"><?php echo $code;?></td>
		<td width="50%" align="center"><img alt="<?php echo $code;?>" src="<?php echo $rep_smileys."/".$image;?>" /></td>
	</tr>
	<?php } ?>
</table>
<br/>
<div align="center">
	[ <a href="javascript:self.close()">Fermer</a> ]<br/><br/>
	<b>Script : </b><br /><a href="http://www.k1der.net" target="_blank">K1der Shoutbox 1.7 Beta9</a>
</div>
</body>
</html>
<?php
exit;
}
?>
<?php
// Si on veut afficher tous les messages
if(isset($_GET["page"])) $page=$_GET["page"];
else $page=1;
$start=50*($page-1);
if (isset($_GET["act"]) && $_GET["act"] == 'histo') $req = sql("SELECT * FROM ".$sql["table"]." ORDER BY id DESC LIMIT ".$start.",50");
// Sinon affichage normal
else $req = sql("SELECT * FROM ".$sql["table"]." ORDER BY id DESC LIMIT 0,".$nb_mess);
$nbre=mysql_fetch_row(sql("SELECT COUNT(*) FROM ".$sql["table"])); //Comptage du nombre de messages

if($scroll=="oui") $barre=18;
else $barre=0;
?>
<table width="<?php echo $largeur; ?>" border="0" cellspacing="0" cellpadding="0">
	<?php
  if (!isset($_GET["act"]) || $_GET["act"] != 'histo')
	{
		if (isset($_COOKIE["shoutbox_pseudo"])) $contenu=$_COOKIE["shoutbox_pseudo"];	
		else $contenu="pseudo";
		$hauteur2=count($smileys)*22+65;
		if($nbre[0]>1) $esse="s";
		else unset($esse);
		if($pl_liens=="haut") {
		$hauteur++;
		?>
 <tr>
	<td align="center">[ <?php if($lien_adm==1) echo "<a href=\"admin.php\" target=\"_blank\">Admin</a> : "; ?><a href="javascript:openscript('<?php echo $_SERVER["SCRIPT_NAME"];?>?act=histo','<?php echo ($largeur+26);?>','600')"><?php if($lien_adm==1) echo "Histo."; else echo "Historique"; ?></a> : <a href="javascript:openscript('<?php echo $_SERVER["SCRIPT_NAME"];?>?act=help','150','<?php echo $hauteur2;?>')">Aide</a> ]</td>
 </tr>
	 <?php
	 }
	 ?>
 <tr> 
  <td align="center"><br />
   <form name="form" action="<?php echo $_SERVER["SCRIPT_NAME"];?>?act=add" method="post">
   <?php
   if(!isset($esse)) $esse="";
	 if(isset($nb_posts)) echo "<b>".$nbre[0]."</b><br/>message".$esse." post�".$esse."<br/><br/>";
	 else $hauteur+=35;
	 ?>
   <input name="pseudo" onfocus="if(this.value=='<?php echo $contenu?>') this.value=''" value="<?php echo $contenu?>" size="17" maxlength="<?php echo $nb_caracp;?>" /><br/>
   <input name="message" onfocus="if(this.value=='message') this.value=''" value="message" size="17" maxlength="<?php echo $nb_carac;?>" /><br/>
   <input type="submit" value="Poster" name="Submit" /><br/><br/>
   [ <a href="<?php echo $_SERVER["SCRIPT_NAME"];?>">Actualiser</a> ] 
   </form><br/>
  </td>
 </tr>
 <?php
 } else {
 ?>
 <tr>
	<td style="text-align:center; font-weight:bold;">Historique</td>
 </tr>
 <tr>
	<td>&nbsp;</td>
 </tr>
 <tr>
	<td style="text-align:right;"><?php echo pagination($page,"act=histo",50,$nbre[0]);?></td>
 </tr>
 <?php
 }
 ?>
 <tr>
  <td>
	<?php
	if(!isset($_GET["act"]) || $_GET["act"]!="histo") {
		echo "<div style=\"overflow:".$scrolling.";height:".($hauteur-160)."px;\">";
		$largeur=$largeur-$barre;
	} else $largeur="100%";
	?>
   <table width="<?php echo $largeur;?>" class="liste" cellspacing="1" cellpadding="2">
   <?php
   $style="td1";
   while($disp = mysql_fetch_array($req)) {
    $date = date("d/m/Y",$disp["timestamp"]);
    $heure = date("H:i",$disp["timestamp"]);
    $mess = replace_aff(substr(stripslashes($disp["mess"]),0,$nb_carac));
    $pseudo = stripslashes($disp["pseudo"]) ;
		if(array_search($pseudo,$lesadmins)===0) $type="a";
		else if(in_array($pseudo,$lesadmins)) $type="m";
		else $type="v";
   ?>
 <tr>
     <td width="<?php echo $largeur;?>" class="<?php echo $style;?>">
      <a class="pseudo<?php echo $type;?>" onmouseover="affiche('','le <?php echo $date;?>&lt;br/&gt;� <?php echo $heure;?>')" onmouseout="affiche('cache')"><?php echo $pseudo;?></a> : <?php echo $mess."\n";?>
     </td>
    </tr>
    <?php
    if ($style=="td1") $style="td2";
    else $style="td1";
    }
    ?>
	</table>
	<?php if(!isset($_GET["act"]) || $_GET["act"]!="histo") echo "</div>"; ?>
  </td>
 </tr>
<?php if(isset($_GET["act"]) && $_GET["act"]=="histo") { ?>
 <tr>
	<td style="text-align:right;"><?php echo pagination($page,"act=histo",50,$nbre[0]);?></td>
 </tr>
<?php } else if($pl_liens=="bas") {
?>
 <tr>
	<td height="10px"></td>
 </tr>
 <tr>
	<td align="center">[ <?php if($lien_adm==1) echo "<a href=\"admin.php\" target=\"_blank\">Admin</a> : "; ?><a href="javascript:openscript('<?php echo $_SERVER["SCRIPT_NAME"];?>?act=histo','<?php echo ($largeur+26);?>','600')"><?php if($lien_adm==1) echo "Histo."; else echo "Historique"; ?></a> : <a href="javascript:openscript('<?php echo $_SERVER["SCRIPT_NAME"];?>?act=help','150','<?php echo $hauteur2;?>')">Aide</a> ]</td>
 </tr>
<?php } ?>
</table>
</body>
</html>