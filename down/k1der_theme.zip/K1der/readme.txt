-=Th�me de bureau K1der=-
Merci d'avoir t�l�charg� notre (superbe) th�me -=k1der=-,
voici comment installer votre nouveau th�me de bureau:
	
	1.D�zippez les fichiers ci-joints dans 
	un dossier quelquonque ("Theme" par exemple).

	2.Lancez l'�x�cutable de windows pour les th�mes.

	3.Choisissez "autre" et s�lectionnez le fichier
	"k1der.theme" dans le r�pertoire o� vous l'avez
	d�zipp�.

Voil�, vous avez maintenant un (magnifique) th�me de bureau. 
Enjoy ;)